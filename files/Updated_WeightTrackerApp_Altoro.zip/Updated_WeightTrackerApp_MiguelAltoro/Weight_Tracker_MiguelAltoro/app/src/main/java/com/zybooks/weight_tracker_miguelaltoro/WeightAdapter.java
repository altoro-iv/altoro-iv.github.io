package com.zybooks.weight_tracker_miguelaltoro;

import android.app.AlertDialog;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Adapter to display Weight objects in a RecyclerView.
 * Updated for CS 499 Milestone Two enhancement:
 * Uses Weight model instead of raw strings
 * Uses DataRepository for cleaner DB access
 */
public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    private List<Weight> weightList;
    private DataRepository repository;

    public WeightAdapter(List<Weight> weightList, DataRepository repository) {
        this.weightList = weightList;
        this.repository = repository;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.weight_row_item, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        Weight weight = weightList.get(position);
        holder.weightText.setText(weight.getValue() + " lbs - " + weight.getDate());

        // Delete button
        holder.deleteButton.setOnClickListener(v -> {
            repository.deleteWeight(weight.getValue(), weight,getDate());
            weightList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, weightList.size());
        });

        // Edit button
        holder.editButton.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(holder.itemView.getContext());
            builder.setTitle("Edit Weight");

            final EditText input = new EditText(holder.itemView.getContext());
            input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            input.setText(weight.getValue());
            builder.setView(input);

            builder.setPositiveButton("Save", (dialog, which) -> {
                String newWeight = input.getText().toString().trim();
                if (!newWeight.isEmpty()) {
                    repository.updateWeight(weight.getValue(), weight.getDate(), newWeight);

                    // Refresh list from repo
                    weightList.clear();
                    weightList.addAll(repository.getAllWeights());
                    notifyDataSetChanged();
                }
            });

            builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
            builder.show();
        });
    }

    @Override
    public int getItemCount() {
        return weightList.size();
    }

    static class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView weightText;
        Button deleteButton;
        Button editButton;

        WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            weightText = itemView.findViewById(R.id.weightText);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            editButton = itemView.findViewById(R.id.editButton);
        }
    }
}
