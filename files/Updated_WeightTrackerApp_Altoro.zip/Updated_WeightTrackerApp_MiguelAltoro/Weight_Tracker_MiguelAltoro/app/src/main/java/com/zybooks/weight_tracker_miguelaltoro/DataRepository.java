// Enhancement for CS 499 Milestone Two
// DataRepository.java
// Author: Miguel Altoro IV

package com.zybooks.weight_tracker_miguelaltoro;

import android.content.Context;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Repository that isolates data access from UI.
 * Converts DatabaseHelper results (Strings) into Weight model objects.
 */
public class DataRepository {

    private static final String ROW_SEPARATOR = " lbs - ";

    private final DatabaseHelper dbHelper;

    public DataRepository(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    /**
     * Insert a new weight (date is assigned in DatabaseHelper).
     * return true if successful, false otherwise.
     */
    public boolean addWeight(String value) {
        if (TextUtils.isEmpty(value)) return false;
        try {
            float v = Float.parseFloat(value);
            if (v <= 0f) return false;
        } catch (NumberFormatException e) {
            return false;
        }
        return dbHelper.insertWeight(value);
    }

    /**
     * Get all weights as a list of Weight objects.
     * Parses strings like "200 lbs - 09/21/2025" into Weight("200", "09/21/2025").
     */
    public List<Weight> getAllWeights() {
        ArrayList<String> rows = dbHelper.getAllWeights();
        List<Weight> result = new ArrayList<>();
        if (rows == null) return result;

        for (String row : rows) {
            if (row == null) continue;
            String[] parts = row.split(ROW_SEPARATOR);
            if (parts.length == 2) {
                String value = parts[0].trim();
                String date = parts[1].trim();
                result.add(new Weight(value, date));
            } else {
                // Fallback: if format is unexpected, store full row as value
                result.add(new Weight(row, ""));
            }
        }
        return result;
    }

    /**
     * Delete a weight by its value and date.
     */
    public boolean deleteWeight(String value, String date) {
        if (TextUtils.isEmpty(value) || TextUtils.isEmpty(date)) return false;
        return dbHelper.deleteWeight(value, date);
    }

    /**
     * Update a specific weight entry identified by old value + date.
     */
    public boolean updateWeight(String oldValue, String date, String newValue) {
        if (TextUtils.isEmpty(date) || TextUtils.isEmpty(newValue)) return false;
        try {
            float v = Float.parseFloat(newValue);
            if (v <= 0f) return false;
        } catch (NumberFormatException e) {
            return false;
        }
        return dbHelper.updateWeight(oldValue, date, newValue);
    }
}

