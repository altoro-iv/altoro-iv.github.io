package com.zybooks.weight_tracker_miguelaltoro;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DataActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "MyPrefsFile";
    private static final String GOAL_KEY = "goal_weight";

    // New: use a repository for DB operations from the Activity
    private DataRepository repository;

    // Keep DatabaseHelper only because the current WeightAdapter expects it
    // Will later refactor the adapter to use the repository too.
    private DatabaseHelper db;

    private WeightAdapter adapter;
    private List<Weight> weights;
    private ArrayList<String> weights;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        // Initialize repository and (for now) DB helper for the adapter
        repository = new DataRepository(this);
        db = new DatabaseHelper(this);

        // Load initial data via the repository
        weights = repository.getAllWeights();

        EditText weightInput = findViewById(R.id.weightInput);
        Button addWeightButton = findViewById(R.id.addWeightButton);
        EditText goalWeightInput = findViewById(R.id.goalWeightInput);
        Button setGoalButton = findViewById(R.id.setGoalWeightButton);
        RecyclerView recyclerView = findViewById(R.id.weightRecyclerView);

        // Adapter takes (weights, repository)
        adapter = new WeightAdapter(weights, repository);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Set Goal Weight
        setGoalButton.setOnClickListener(v -> {
            String goalWeight = goalWeightInput.getText().toString().trim();
            if (!goalWeight.isEmpty()) {
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit().putString(GOAL_KEY, goalWeight).apply();
                Toast.makeText(this, "Goal weight set to " + goalWeight, Toast.LENGTH_SHORT).show();
                goalWeightInput.setText("");
            } else {
                Toast.makeText(this, "Enter a goal weight", Toast.LENGTH_SHORT).show();
            }
        });

        // Add new weight and compare with goal
        addWeightButton.setOnClickListener(v -> {
            String weight = weightInput.getText().toString().trim();

            // Basic validation: required, numeric, positive
            if (weight.isEmpty()) {
                Toast.makeText(this, "Enter a weight", Toast.LENGTH_SHORT).show();
                return;
            }
            float currentWeight;
            try {
                currentWeight = Float.parseFloat(weight);
                if (currentWeight <= 0f) {
                    Toast.makeText(this, "Weight must be greater than 0", Toast.LENGTH_SHORT).show();
                    return;
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Weight must be a number", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean ok = repository.addWeight(weightStr);
            if (ok) {
                // Refresh list from repository
                refreshList();
                weightInput.setText("");

                // Goal check
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                String goalWeightStr = prefs.getString(GOAL_KEY, null);
                if (goalWeightStr != null) {
                    try {
                        float goalWeight = Float.parseFloat(goalWeightStr);
                        if (currentWeight <= goalWeight) {
                            Toast.makeText(this,
                                    "🎉 Goal reached: " + currentWeight + " lbs!",
                                    Toast.LENGTH_LONG).show();
                        }
                    } catch (NumberFormatException ignore) {
                        // ignore bad goal input
                    }
                }

                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Could not save entry", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void refreshList() {
        weights.clear();
        weights.addAll(repository.getAllWeights());
        adapter.notifyDataSetChanged();
    }
}
