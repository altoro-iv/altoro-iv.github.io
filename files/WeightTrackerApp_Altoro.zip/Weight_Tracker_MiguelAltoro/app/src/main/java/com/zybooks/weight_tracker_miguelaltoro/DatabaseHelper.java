package com.zybooks.weight_tracker_miguelaltoro;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "weight_tracker.db";
    private static final int DB_VERSION = 2;

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (username TEXT PRIMARY KEY, password TEXT)");
        db.execSQL("CREATE TABLE weights (id INTEGER PRIMARY KEY AUTOINCREMENT, value TEXT, date TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE weights ADD COLUMN date TEXT");
        }
    }

    public boolean addUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username = ?", new String[]{username});
        if (cursor.moveToFirst()) {
            cursor.close();
            return false;
        }
        cursor.close();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        db.insert("users", null, values);
        return true;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username = ? AND password = ?", new String[]{username, password});
        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }

    public void insertWeight(String value) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("value", value);

        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        values.put("date", date);

        db.insert("weights", null, values);
    }

    public ArrayList<String> getAllWeights() {
        ArrayList<String> weights = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT value, date FROM weights", null);

        if (cursor.moveToFirst()) {
            do {
                String value = cursor.getString(0);
                String date = cursor.getString(1);
                weights.add(value + " lbs - " + date);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return weights;
    }

    public void deleteWeight(String value, String date) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("weights", "value = ? AND date = ?", new String[]{value, date});
    }

    public void updateWeight(String originalEntry, String newWeight, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("value", newWeight);

        String oldWeight = originalEntry.split(" lbs - ")[0].trim();
        String oldDate = date.trim();

        db.update("weights", values, "value=? AND date=?", new String[]{oldWeight, oldDate});
    }
}