package com.zybooks.weight_tracker_miguelaltoro;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class DataActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "MyPrefsFile";
    private static final String GOAL_KEY = "goal_weight";

    private DatabaseHelper db;
    private WeightAdapter adapter;
    private ArrayList<String> weights;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        db = new DatabaseHelper(this);
        weights = db.getAllWeights();

        EditText weightInput = findViewById(R.id.weightInput);
        Button addWeightButton = findViewById(R.id.addWeightButton);
        EditText goalWeightInput = findViewById(R.id.goalWeightInput);
        Button setGoalButton = findViewById(R.id.setGoalWeightButton);
        RecyclerView recyclerView = findViewById(R.id.weightRecyclerView);

        adapter = new WeightAdapter(weights, db);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Set Goal Weight
        setGoalButton.setOnClickListener(v -> {
            String goalWeight = goalWeightInput.getText().toString().trim();
            if (!goalWeight.isEmpty()) {
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit().putString(GOAL_KEY, goalWeight).apply();
                Toast.makeText(this, "Goal weight set to " + goalWeight, Toast.LENGTH_SHORT).show();
                goalWeightInput.setText("");
            }
        });

        // Add new weight and compare with goal
        addWeightButton.setOnClickListener(v -> {
            String weight = weightInput.getText().toString().trim();
            if (!weight.isEmpty()) {
                db.insertWeight(weight);
                weights.clear();
                weights.addAll(db.getAllWeights());
                adapter.notifyDataSetChanged();
                weightInput.setText("");

                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                String goalWeightStr = prefs.getString(GOAL_KEY, null);
                if (goalWeightStr != null) {
                    try {
                        float currentWeight = Float.parseFloat(weight);
                        float goalWeight = Float.parseFloat(goalWeightStr);
                        if (currentWeight <= goalWeight) {
                            Toast.makeText(this, "🎉 Goal reached: " + currentWeight + " lbs!", Toast.LENGTH_LONG).show();
                        }
                    } catch (NumberFormatException e) {
                        // Do nothing
                    }
                }
            }
        });
    }
}
