package com.zybooks.weight_tracker_miguelaltoro;

import android.app.AlertDialog;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    private ArrayList<String> weightList;
    private DatabaseHelper db;

    public WeightAdapter(ArrayList<String> weightList, DatabaseHelper db) {
        this.weightList = weightList;
        this.db = db;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.weight_row_item, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        String weight = weightList.get(position);
        holder.weightText.setText(weight);

        holder.deleteButton.setOnClickListener(v -> {
            // Split the entry into weight and date
            String[] parts = weight.split(" lbs - ");
            if (parts.length == 2) {
                String value = parts[0];
                String date = parts[1];
                db.deleteWeight(value, date);
                weightList.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, weightList.size());
            }
        });

        holder.editButton.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(holder.itemView.getContext());
            builder.setTitle("Edit Weight");

            final EditText input = new EditText(holder.itemView.getContext());
            input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

            String[] parts = weight.split(" lbs - ");
            String oldWeight = parts[0];
            String oldDate = parts[1];

            input.setText(oldWeight);
            builder.setView(input);

            builder.setPositiveButton("Save", (dialog, which) -> {
                String newWeight = input.getText().toString().trim();
                if (!newWeight.isEmpty()) {
                    db.updateWeight(weight, newWeight, oldDate);

                    // Refresh the list
                    weightList.clear();
                    weightList.addAll(db.getAllWeights());
                    notifyDataSetChanged();
                }
            });

            builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

            builder.show();
        });

    }

    @Override
    public int getItemCount() {
        return weightList.size();
    }

    static class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView weightText;
        Button deleteButton;
        Button editButton;

        WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            weightText = itemView.findViewById(R.id.weightText);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            editButton = itemView.findViewById(R.id.editButton);
        }
    }
}
